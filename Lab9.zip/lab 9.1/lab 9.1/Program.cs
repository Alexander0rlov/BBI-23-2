﻿using lab_9._1.Serialization;
using System.Text.Json;
using System.Xml.Linq;

public class Competitor
{
    public string Name { get; set; }
    public int Res { get; set; }
    public bool IsDisqualified { get; set ; }

    public Competitor(string name, int res1, int res2)
    {
        Name = name;
        Res = Math.Max(res1, res2);
        IsDisqualified = false;
    }

    public Competitor() {} //for XML

    public void Print()
    {
        Console.WriteLine($"Name {Name}, Score {Res}, Status {IsDisqualified}"); 
    }
    public void Disqualify()
    {
        Res = 0;
        IsDisqualified = true;
    }
}
class Program
{
    public static void Main()
    {
        Competitor[] competitors =
        {
            new("Oleg", 135, 123),
            new("Vitalya", 137, 121),
            new("Leha", 115, 136),
            new("Gena", 134, 126),
            new("Vovan", 112, 143)
        };
        competitors[0].Disqualify();
        Sort(competitors);

        #region FilePath
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "FilesForLab9";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] file_names =
        [
            "9.1.json",
            "9.1.xml"
        ];
        #endregion

        #region Serialization
        SerializeManager[] serializers =
        [
            new JsonMySerializer(),
            new XmlMySerializer()
        ];

        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(competitors, Path.Combine(path, file_names[i]));
        }

        for (int i = 0; i < serializers.Length; i++)
        {
            competitors = serializers[i].Read<Competitor[]>(Path.Combine(path, file_names[i]));
            foreach (var competitor in competitors)
            {
                competitor.Print();
            }
        }
        #endregion

    }
    static void Sort(Competitor[] competitors)
    {
        for (int i = 1; i < competitors.Length; i++)
        {
            Competitor temp = competitors[i];
            int j = i - 1;

            while (j >= 0 && competitors[j].Res < temp.Res)
            {
                competitors[j + 1] = competitors[j];
                j--;
            }
            competitors[j + 1] = temp;
        }
    }
}