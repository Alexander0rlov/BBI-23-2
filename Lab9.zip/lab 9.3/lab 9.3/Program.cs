﻿using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Xml.Serialization;
using lab_9._1.Serialization;

public class FootballTeam
{
    public string Name { get; set; }
    public int Points { get; set; }
    public int Group { get; set; }
    public string Gender { get; set; }

    public FootballTeam(string name, int points, int group, string gender)
    {
        Name = name;
        Points = points;
        Group = group;
        Gender = gender;
    }

    public FootballTeam() { }
    public virtual void Print()
    {
        Console.WriteLine($"Название {Name} Пол {Gender} Баллы {Points} ");
    }
}

public class MaleTeam : FootballTeam
{
    public MaleTeam(string name, int points, int group, string gender) : base(name, points, group, gender) { Gender = "Мужская команда"; }
    public MaleTeam() { }   
    public override void Print()
    {
        base.Print();
    }
}

public class FemaleTeam : FootballTeam
{
    public FemaleTeam(string name, int points, int group, string gender) : base(name, points, group, gender) { Gender = "Женская команда"; }
    
    public FemaleTeam() { }
    public override void Print()
    {
        base.Print();
    }
}

class Program
{
    static void Main(string[] args)
    {
        FootballTeam[] FTeam1 = new FootballTeam[12];
        for (int i = 0; i < 12; i++)
        {
            FTeam1[i] = new FootballTeam($"Team {i + 1}", new Random().Next(0, 50), 1, "Female");
        }
        FootballTeam[] FTeam2 = new FootballTeam[12];
        for (int i = 0; i < 12; i++)
        {
            FTeam2[i] = new FootballTeam($"Team {i + 1}", new Random().Next(0, 50), 2, "Female");
        }
        FootballTeam[] MTeam1 = new FootballTeam[12];
        for (int i = 0; i < 12; i++)
        {
            MTeam1[i] = new FootballTeam($"Team {i + 1}", new Random().Next(0, 50), 1, "Male");
        }
        FootballTeam[] MTeam2 = new FootballTeam[12];
        for (int i = 0; i < 12; i++)
        {
            MTeam2[i] = new FootballTeam($"Team {i + 1}", new Random().Next(0, 50), 2, "Male");
        }

        Sort(MTeam1);
        Sort(MTeam2);
        Sort(FTeam1);
        Sort(FTeam2);

        FootballTeam[] Mstage2 = MergeArrays(MTeam1, MTeam2);//все мужские команды по убыванию
        FootballTeam[] Fstage2 = MergeArrays(FTeam1, FTeam2);//все женские команды по убыванию
        FootballTeam[] Finals = MergeArrays(Mstage2, Fstage2);//все команды по убыванию

       
        #region FilePath
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "FilesForLab9";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] file_names =
        [
            "9.3.json",
            "9.3.xml"
        ];
        #endregion

        #region Serialization
        SerializeManager[] serializers =
        [
            new JsonMySerializer(),
            new XmlMySerializer()
        ];

        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(Finals, Path.Combine(path, file_names[i]));
        }

        for (int i = 0; i < serializers.Length; i++)
        {
            Finals = serializers[i].Read<FootballTeam[]>(Path.Combine(path, file_names[i]));
            foreach (var competitor in Finals)
            {
                competitor.Print();
            }
        }
        #endregion

        static FootballTeam[] MergeArrays(FootballTeam[] team1, FootballTeam[] team2)
        {
            FootballTeam[] merged = new FootballTeam[team1.Length + team2.Length];
            int i = 0, j = 0, k = 0;

            while (i < team1.Length && j < team2.Length)
            {
                if (team1[i].Points >= team2[j].Points)
                {
                    merged[k] = team1[i];
                    i++;
                }
                else
                {
                    merged[k] = team2[j];
                    j++;
                }
                k++;
            }

            while (i < team1.Length)
            {
                merged[k] = team1[i];
                i++;
                k++;
            }

            while (j < team2.Length)
            {
                merged[k] = team2[j];
                j++;
                k++;
            }

            return merged;
        }

        static void Sort(FootballTeam[] team)
        {
            for (int i = 1; i < team.Length; i++)
            {
                FootballTeam temp = team[i];
                int j = i - 1;

                while (j >= 0 && team[j].Points < temp.Points)
                {
                    team[j + 1] = team[j];
                    j--;
                }

                team[j + 1] = temp;
            }
        }
    }
}
