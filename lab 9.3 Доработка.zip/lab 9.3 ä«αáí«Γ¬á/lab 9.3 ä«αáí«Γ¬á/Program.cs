﻿using lab_9._1.Serialization;
using Newtonsoft.Json;
using System.Xml.Serialization;

[XmlInclude(typeof(MaleTeam))]
[XmlInclude(typeof(FemaleTeam))]
public class FootballTeam
{
    public string Name { get; set; }
    public int Points { get; set; }
    public int Group { get; set; }
    public string Gender { get; set; }

    public FootballTeam(string name, int points, int group)
    {
        Name = name;
        Points = points;
        Group = group;
        Gender = "";
    }
    public FootballTeam() { }

    public virtual void Write()
    {
        Console.WriteLine($"Название {Name} Пол {Gender} Баллы {Points} ");
    }
}

public class MaleTeam : FootballTeam
{
    [JsonProperty]
    public int DivisionNum { get; set; }
    public MaleTeam(string name, int points, int group, int num) : base(name, points, group) { DivisionNum = num; Gender = "Мужская команда"; }
   
    public MaleTeam() { }
    public override void Write()
    {
        Console.WriteLine($"Название {Name} Пол {Gender} Баллы {Points} Номер дивизиона {DivisionNum} ");
    }
}

public class FemaleTeam : FootballTeam
{
    [JsonProperty]
    public string ColorUniform { get; set; }
    public FemaleTeam(string name, int points, int group, string color) : base(name, points, group) { ColorUniform = color; Gender = "Женская команда"; }
    
    public FemaleTeam() { }
    public override void Write()
    {
        Console.WriteLine($"Название {Name} Пол {Gender} Баллы {Points} Цвет формы {ColorUniform} ");
    }
}

class Program
{
    static void Main(string[] args)
    {
        FemaleTeam[] FTeam1 = new FemaleTeam[12];
        for (int i = 0; i < 12; i++)
        {
            FTeam1[i] = new FemaleTeam($"Team {i + 1}", new Random().Next(0, 50), 1, "red");

        }

        FemaleTeam[] FTeam2 = new FemaleTeam[12];
        for (int i = 0; i < 12; i++)
        {
            FTeam2[i] = new FemaleTeam($"Team {i + 1}", new Random().Next(0, 50), 2, "green");

        }

        MaleTeam[] MTeam1 = new MaleTeam[12];
        for (int i = 0; i < 12; i++)
        {
            MTeam1[i] = new MaleTeam($"Team {i + 1}", new Random().Next(0, 50), 1, 12);

        }

        MaleTeam[] MTeam2 = new MaleTeam[12];
        for (int i = 0; i < 12; i++)
        {
            MTeam2[i] = new MaleTeam($"Team {i + 1}", new Random().Next(0, 50), 2, 23);

        }


        Sort(MTeam1);
        Sort(MTeam2);
        Sort(FTeam1);
        Sort(FTeam2);


        FootballTeam[] Mstage2 = MergeArrays(MTeam1, MTeam2);//все мужские команды по убыванию
        FootballTeam[] Fstage2 = MergeArrays(FTeam1, FTeam2);//все женские команды по убыванию
        FootballTeam[] Finals = MergeArrays(Mstage2, Fstage2);//все команды по убыванию


        //for (int i = 0; i < 6; i++)//вывод 6 лучших команд среди всех 
        //{
        //    Finals[i].Write();
        //}

        #region FilePath
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "FilesForLab9";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] file_names =
        [
            "9.3.json",
            "9.3.xml"
        ];
        #endregion

        #region Serialization
        SerializeManager[] serializers =
        [
            new JsonMySerializer(),
            new XmlMySerializer()
        ];

        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[1].Write(Finals, Path.Combine(path, file_names[1]));
        }

        for (int i = 0; i < serializers.Length; i++)
        {
            Finals = serializers[1].Read<FootballTeam[]>(Path.Combine(path, file_names[1]));
            foreach (var competitor in Finals)
            {
                competitor.Write();
            }
        }
        #endregion


        static FootballTeam[] MergeArrays(FootballTeam[] team1, FootballTeam[] team2)
        {
            FootballTeam[] merged = new FootballTeam[team1.Length + team2.Length];
            int i = 0, j = 0, k = 0;

            while (i < team1.Length && j < team2.Length)
            {
                if (team1[i].Points >= team2[j].Points)
                {
                    merged[k] = team1[i];
                    i++;
                }
                else
                {
                    merged[k] = team2[j];
                    j++;
                }
                k++;
            }

            while (i < team1.Length)
            {
                merged[k] = team1[i];
                i++;
                k++;
            }

            while (j < team2.Length)
            {
                merged[k] = team2[j];
                j++;
                k++;
            }

            return merged;
        }


        static void Sort(FootballTeam[] team)
        {
            for (int i = 1; i < team.Length; i++)
            {
                FootballTeam temp = team[i];
                int j = i - 1;

                while (j >= 0 && team[j].Points < temp.Points)
                {
                    team[j + 1] = team[j];
                    j--;
                }

                team[j + 1] = temp;
            }
        }
    }
}